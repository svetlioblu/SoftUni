function solve() {
	//TODO
}
