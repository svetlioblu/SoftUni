function solve() {
  //TODO
}