function validate() {
    console.log('TODO:...');
}