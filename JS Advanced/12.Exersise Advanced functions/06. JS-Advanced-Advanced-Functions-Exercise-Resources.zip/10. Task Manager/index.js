function solve(){
   // TODO
}
