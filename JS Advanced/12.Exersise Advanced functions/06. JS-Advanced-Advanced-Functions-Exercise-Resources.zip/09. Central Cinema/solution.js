function solve() {
    // TODO
}