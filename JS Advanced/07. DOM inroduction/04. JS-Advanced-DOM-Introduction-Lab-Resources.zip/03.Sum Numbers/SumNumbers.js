function calc() {
    // TODO: sum = num1 + num2
}
