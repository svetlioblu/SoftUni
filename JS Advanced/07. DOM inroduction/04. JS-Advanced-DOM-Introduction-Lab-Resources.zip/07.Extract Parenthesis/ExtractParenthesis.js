function extract() {

}