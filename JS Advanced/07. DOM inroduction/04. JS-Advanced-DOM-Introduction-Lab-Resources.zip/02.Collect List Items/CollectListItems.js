function extractText() {
    // TODO
}