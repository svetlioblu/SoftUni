function editElement() {
    // TODO
}