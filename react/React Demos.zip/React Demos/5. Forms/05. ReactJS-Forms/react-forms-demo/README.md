# Getting Start
Unzip server.zip
run the server with CMD -> node server.js
run the client with CMD
+ npm install
+ npm start
Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.

## Users
Guests => can Register, LogIn and Read all services from './services' plus its details. Cannot Delete,Edit and Add
LoggedUser => can add and read all services from './services'. Can Read, Edit and Delete only its own services from './MyProjects'

### Highlites of the app
+ There are used 2 separate contexts. For the users and for the data
+ It is implemented persiting state by using the localStorage
+ Routing plus Route guards preventing access to forms for guests 
+ Controlled Form validation on submit
+ Server Responce validations on 
=> non existing user and password
=> non server data (services)

