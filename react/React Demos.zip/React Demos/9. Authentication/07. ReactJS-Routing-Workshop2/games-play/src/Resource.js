
function App() {
    return (
      <div id="box">
        {/* <!-- Edit Page ( Only for the creator )--> */}
        
  
        {/* <!--Details Page--> */}

      </div>
    );
  }
  
  export default App;
  